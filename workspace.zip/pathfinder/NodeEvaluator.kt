package ink.ptms.navigation.pathfinder

import io.izzel.taboolib.module.nms.impl.Position
import it.unimi.dsi.fastutil.ints.Int2ObjectMap
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap
import org.bukkit.World
import org.bukkit.util.NumberConversions

/**
 * Navigation
 * ink.ptms.navigation.pathfinder.NodeEvaluator
 * net.minecraft.world.level.pathfinder.NodeEvaluator
 *
 * @author sky
 * @since 2021/2/21 6:29 下午
 */
abstract class NodeEvaluator {

    // PathNavigationRegion
    // a
    protected var world: World? = null
    // mob
    // b
    protected var nodeEntity: NodeEntity? = null
    protected val nodes: Int2ObjectMap<Node> = Int2ObjectOpenHashMap()
    // d
    protected var entityWidth = 0
    // e
    protected var entityHeight = 0
    // f
    protected var entityDepth = 0
    // g
    protected var canPassDoors = true
    // h
    protected var canOpenDoors = false
    // i
    // e()
    protected var canFloat = true

    open fun prepare(world: World, nodeEntity: NodeEntity) {
        this.world = world
        this.nodeEntity = nodeEntity
        this.nodes.clear()
        this.entityWidth = NumberConversions.floor(nodeEntity.width)
        this.entityHeight = NumberConversions.floor(nodeEntity.height)
        this.entityDepth = NumberConversions.floor(nodeEntity.width)
    }

    open fun done() {
        this.world = null
        this.nodeEntity = null
    }

    fun getNode(position: Position): Node {
        return getNode(position.x, position.y, position.z)
    }

    fun getNode(x: Int, y: Int, z: Int): Node {
        return nodes.computeIfAbsent(Node.createHash(x, y, z)) { Node(x, y, z) }
    }

    abstract fun getStart(): Node

    abstract fun getGoal(x: Double, y: Double, z: Double): Target

    abstract fun getNeighbors(nodes: Array<Node?>, node: Node): Int

    /**
     * @param world net.minecraft.world.level.BlockGetter
     */
    abstract fun getBlockPathType(
        world: World,
        x: Int,
        y: Int,
        z: Int,
        nodeEntity: NodeEntity,
        entityWidth: Int,
        entityHeight: Int,
        entityDepth: Int,
        canOpenDoors: Boolean,
        canPassDoors: Boolean
    ): BlockPathTypes

    abstract fun getBlockPathType(
        world: World,
        x: Int,
        y: Int,
        z: Int
    ): BlockPathTypes
}