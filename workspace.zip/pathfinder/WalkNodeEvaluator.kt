package ink.ptms.navigation.pathfinder

import ink.ptms.navigation.pathfinder.bukkit.BoundingBox
import ink.ptms.navigation.pathfinder.bukkit.NMS
import ink.ptms.navigation.pathfinder.Fluid.Companion.getFluid
import ink.ptms.navigation.util.*
import io.izzel.taboolib.module.nms.impl.Position
import it.unimi.dsi.fastutil.longs.Long2ObjectMap
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
import it.unimi.dsi.fastutil.objects.Object2BooleanMap
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap
import org.bukkit.Material
import org.bukkit.World
import org.bukkit.block.Block
import org.bukkit.util.NumberConversions
import org.bukkit.util.Vector
import java.util.*

import java.util.EnumSet


/**
 * Navigation
 * ink.ptms.navigation.pathfinder.WalkNodeEvaluator
 * net.minecraft.world.level.pathfinder.WalkNodeEvaluator
 *
 * @author sky
 * @since 2021/2/21 7:29 下午
 */
open class WalkNodeEvaluator : NodeEvaluator() {

    protected var oldWaterCost = 0f
    protected val pathTypesByPosCache: Long2ObjectMap<BlockPathTypes> = Long2ObjectOpenHashMap()
    protected val collisionCache: Object2BooleanMap<BoundingBox> = Object2BooleanOpenHashMap()

    override fun prepare(world: World, nodeEntity: NodeEntity) {
        super.prepare(world, nodeEntity)
        this.oldWaterCost = nodeEntity.getPathfindingMalus(BlockPathTypes.WATER)
    }

    override fun done() {
        this.nodeEntity?.setPathfindingMalus(BlockPathTypes.WATER, this.oldWaterCost)
        this.pathTypesByPosCache.clear()
        this.collisionCache.clear()
        super.done()
    }

    override fun getStart(): Node {
        val position = Position(0, 0, 0)
        var y = nodeEntity!!.location.blockY
        var block = world!!.getBlockAt(position.set(nodeEntity!!.location.blockX, y, nodeEntity!!.location.blockZ))
        var blockposition: Position
        if (!nodeEntity!!.canStandOnFluid(block.getFluid())) {
            if (canFloat && nodeEntity!!.isInWater()) {
                while (true) {
                    if (!block.isLiquid) {
                        --y
                        break
                    }
                    ++y
                    block = world!!.getBlockAt(position.set(nodeEntity!!.location.blockX, y, nodeEntity!!.location.blockZ))
                }
            } else if (nodeEntity!!.isOnGround()) {
                y = NumberConversions.floor(nodeEntity!!.location.y + 0.5)
            } else {
                blockposition = Position.at(nodeEntity!!.location)
                while (!blockposition.toBlock(block.world).type.isSolid && blockposition.y > 0) {
                    blockposition = blockposition.down()
                }
                y = blockposition.up().y
            }
        } else {
            while (true) {
                if (!nodeEntity!!.canStandOnFluid(block.getFluid())) {
                    --y
                    break
                }
                ++y
                block = world!!.getBlockAt(position.set(nodeEntity!!.location.blockX, y, nodeEntity!!.location.blockZ))
            }
        }
        blockposition = Position.at(nodeEntity!!.location)
        val blockPathType = getCachedBlockType(nodeEntity!!, blockposition.x, y, blockposition.z)
        if (nodeEntity!!.getPathfindingMalus(blockPathType) < 0.0f) {
            val boundingBox = nodeEntity!!.boundingBox
            if (hasPositiveMalus(position.set(boundingBox.minX, y.toDouble(), boundingBox.minZ))
                || hasPositiveMalus(position.set(boundingBox.minX, y.toDouble(), boundingBox.maxZ))
                || hasPositiveMalus(position.set(boundingBox.maxX, y.toDouble(), boundingBox.minZ))
                || hasPositiveMalus(position.set(boundingBox.maxX, y.toDouble(), boundingBox.maxZ))
            ) {
                val node = getNode(position)
                node.type = getCachedBlockType(nodeEntity!!, node.asBlockPos())
                node.costMalus = nodeEntity!!.getPathfindingMalus(node.type)
                return node
            }
        }
        val node = getNode(blockposition.x, y, blockposition.z)
        node.type = getCachedBlockType(nodeEntity!!, node.asBlockPos())
        node.costMalus = nodeEntity!!.getPathfindingMalus(node.type)
        return node
    }

    override fun getGoal(x: Double, y: Double, z: Double): Target {
        return Target(getNode(NumberConversions.floor(x), NumberConversions.floor(y), NumberConversions.floor(z)))
    }

    override fun getNeighbors(nodes: Array<Node?>, node: Node): Int {
        var neighbors = 0
        var j = 0
        val pathType0 = getCachedBlockType(nodeEntity!!, node.x, node.y + 1, node.z)
        val pathType1 = getCachedBlockType(nodeEntity!!, node.x, node.y, node.z)
        if (nodeEntity!!.getPathfindingMalus(pathType0) >= 0.0f && pathType1 != BlockPathTypes.STICKY_HONEY) {
            j = d(nodeEntity!!.G.coerceAtMost(1f))
        }
        val floorLevel = getFloorLevel(world!!, Position(node.x, node.y, node.z))
        debug("  floorLevel $floorLevel")
        val node1 = getLandNode(node.x, node.y, node.z + 1, j, floorLevel, Direction.SOUTH, pathType1)
        debug("  getNeighbors SOUTH $node1 ${isNeighborValid(node1?.debug(), node)}")
        if (isNeighborValid(node1, node)) {
            nodes[neighbors++] = node1
        }
        val node2 = getLandNode(node.x - 1, node.y, node.z, j, floorLevel, Direction.WEST, pathType1)
        debug("  getNeighbors WEST $node2 ${node2?.costMalus} ${isNeighborValid(node2?.debug(), node)}")
        if (isNeighborValid(node2, node)) {
            nodes[neighbors++] = node2
        }
        val node3 = getLandNode(node.x + 1, node.y, node.z, j, floorLevel, Direction.EAST, pathType1)
        debug("  getNeighbors EASY $node3 ${isNeighborValid(node3?.debug(), node)}")
        if (isNeighborValid(node3, node)) {
            nodes[neighbors++] = node3
        }
        val node4 = getLandNode(node.x, node.y, node.z - 1, j, floorLevel, Direction.NORTH, pathType1)
        debug("  getNeighbors NORTH $node4 ${isNeighborValid(node4?.debug(), node)}")
        if (isNeighborValid(node4, node)) {
            nodes[neighbors++] = node4
        }
        val node5 = getLandNode(node.x - 1, node.y, node.z - 1, j, floorLevel, Direction.NORTH, pathType1)
        debug("  getNeighbors NORTH 2 $node5 ${isNeighborValid(node5?.debug(), node)}")
        if (this.isDiagonalValid(node, node2, node4, node5)) {
            nodes[neighbors++] = node5
        }
        val node6 = getLandNode(node.x + 1, node.y, node.z - 1, j, floorLevel, Direction.NORTH, pathType1)
        debug("  getNeighbors NORTH 3 $node6 ${isNeighborValid(node6?.debug(), node)}")
        if (this.isDiagonalValid(node, node3, node4, node6)) {
            nodes[neighbors++] = node6
        }
        val node7 = getLandNode(node.x - 1, node.y, node.z + 1, j, floorLevel, Direction.SOUTH, pathType1)
        debug("  getNeighbors SOUTH 2 $node7 ${isNeighborValid(node7?.debug(), node)}")
        if (this.isDiagonalValid(node, node2, node1, node7)) {
            nodes[neighbors++] = node7
        }
        val node8 = getLandNode(node.x + 1, node.y, node.z + 1, j, floorLevel, Direction.SOUTH, pathType1)
        debug("  getNeighbors SOUTH 3 $node8 ${isNeighborValid(node8?.debug(), node)}")
        if (this.isDiagonalValid(node, node3, node1, node8)) {
            nodes[neighbors++] = node8
        }
        return neighbors
    }

    override fun getBlockPathType(
        world: World,
        x: Int,
        y: Int,
        z: Int,
        nodeEntity: NodeEntity,
        entityWidth: Int,
        entityHeight: Int,
        entityDepth: Int,
        canOpenDoors: Boolean,
        canPassDoors: Boolean
    ): BlockPathTypes {
        val enumSet = EnumSet.noneOf(BlockPathTypes::class.java)
        val position = Position.at(nodeEntity.location)
        val pathTypes = getBlockPathTypes(world, x, y, z, entityWidth, entityHeight, entityDepth, canOpenDoors, canPassDoors, enumSet, BlockPathTypes.BLOCKED, position)
        if (enumSet.contains(BlockPathTypes.FENCE)) {
            return BlockPathTypes.FENCE
        }
        if (enumSet.contains(BlockPathTypes.UNPASSABLE_RAIL)) {
            return BlockPathTypes.UNPASSABLE_RAIL
        }
        var pathTypes1 = BlockPathTypes.BLOCKED
        enumSet.forEach {
            if (nodeEntity.getPathfindingMalus(it) < 0.0f) {
                return it
            }
            if (nodeEntity.getPathfindingMalus(it) < nodeEntity.getPathfindingMalus(pathTypes1)) {
                return@forEach
            }
            pathTypes1 = it
        }
        return if (pathTypes === BlockPathTypes.OPEN && nodeEntity.getPathfindingMalus(pathTypes1) == 0.0f && entityWidth <= 1) {
            BlockPathTypes.OPEN
        } else {
            pathTypes1
        }
    }

    // recode: getTypeAsEntity
    fun getBlockPathTypes(
        world: World,
        x: Int,
        y: Int,
        z: Int,
        entityWidth: Int,
        entityHeight: Int,
        entityDepth: Int,
        canOpenDoors: Boolean,
        canPassDoors: Boolean,
        enumSet: EnumSet<BlockPathTypes>,
        pathType: BlockPathTypes,
        position: Position
    ): BlockPathTypes {
        var pathTypes = pathType
        for (k1 in 0 until entityWidth) {
            for (l1 in 0 until entityHeight) {
                for (i2 in 0 until entityDepth) {
                    val j2 = k1 + x
                    val k2 = l1 + y
                    val l2 = i2 + z
                    var blockPathTypes = getBlockPathType(world, j2, k2, l2)
                    blockPathTypes = evaluateBlockPathType(world, canOpenDoors, canPassDoors, position, blockPathTypes)
                    if (k1 == 0 && l1 == 0 && i2 == 0) {
                        pathTypes = blockPathTypes
                    }
                    enumSet.add(blockPathTypes)
                }
            }
        }
        return pathTypes
    }

    override fun getBlockPathType(world: World, x: Int, y: Int, z: Int): BlockPathTypes {
        return getBlockPathTypeStatic(world, Position(x, y, z))
    }

    // a
    fun getCachedBlockType(nodeEntity: NodeEntity, x: Int, y: Int, z: Int): BlockPathTypes {
        return getCachedBlockType(nodeEntity, Position(x, y, z))
    }

    // a
    fun getCachedBlockType(nodeEntity: NodeEntity, position: Position): BlockPathTypes {
        return pathTypesByPosCache.computeIfAbsent(position.hash()) {
            getBlockPathType(world!!, position.x, position.y, position.z, nodeEntity, entityWidth, entityHeight, entityDepth, canOpenDoors, canPassDoors)
        }
    }

    // recode: getTypeAsWalkable
    fun getBlockPathTypeStatic(world: World, position: Position): BlockPathTypes {
        val x = position.x
        val y = position.y
        val z = position.z
        var pathType = getBlockPathTypeRaw(world, position)
        if (pathType == BlockPathTypes.OPEN && y >= 1) {
            val pathType1 = getBlockPathTypeRaw(world, position.set(x, y - 1, z))
            pathType = if (pathType1 != BlockPathTypes.WALKABLE
                && pathType1 != BlockPathTypes.OPEN
                && pathType1 != BlockPathTypes.WATER
                && pathType1 != BlockPathTypes.LAVA
            ) {
                BlockPathTypes.WALKABLE
            } else {
                BlockPathTypes.OPEN
            }
            if (pathType1 == BlockPathTypes.DAMAGE_FIRE) {
                pathType = BlockPathTypes.DAMAGE_FIRE
            }
            if (pathType1 == BlockPathTypes.DAMAGE_CACTUS) {
                pathType = BlockPathTypes.DAMAGE_CACTUS
            }
            if (pathType1 == BlockPathTypes.DAMAGE_OTHER) {
                pathType = BlockPathTypes.DAMAGE_OTHER
            }
            if (pathType1 == BlockPathTypes.STICKY_HONEY) {
                pathType = BlockPathTypes.STICKY_HONEY
            }
        }
        if (pathType == BlockPathTypes.WALKABLE) {
            pathType = checkNeighbourBlocks(world, position.set(x, y, z), pathType)
        }
        return pathType
    }

    // recode: getRawType
    fun getBlockPathTypeRaw(world: World, position: Position): BlockPathTypes {
        val block = world.getBlockAtIfLoaded(position)
        return if (block == null) {
            BlockPathTypes.BLOCKED
        } else {
            Material.COCOA
            val material = block.type.name
            when {
                block.type.isAir -> {
                    BlockPathTypes.OPEN
                }
                material.endsWith("TRAPDOOR") || material.endsWith("TRAP_DOOR") || material == "LILY_PAD" -> {
                    BlockPathTypes.TRAPDOOR
                }
                else -> {
                    when {
                        material.endsWith("CACTUS") -> {
                            BlockPathTypes.DAMAGE_CACTUS
                        }
                        material == "SWEET_BERRY_BUSH" -> {
                            BlockPathTypes.DAMAGE_OTHER
                        }
                        material == "HONEY_BLOCK" -> {
                            BlockPathTypes.STICKY_HONEY
                        }
                        material.endsWith("COCOA") -> {
                            BlockPathTypes.COCOA
                        }
                        else -> {
                            val fluid = block.getFluid()
                            when {
                                fluid == Fluid.WATER || fluid == Fluid.FLOWING_WATER -> {
                                    BlockPathTypes.WATER
                                }
                                fluid == Fluid.LAVA || fluid == Fluid.FLOWING_LAVA -> {
                                    BlockPathTypes.LAVA
                                }
                                isBurningBlock(block) -> {
                                    BlockPathTypes.DAMAGE_FIRE
                                }
                                block.isIronDoor() && !block.isOpened() -> {
                                    BlockPathTypes.DOOR_IRON_CLOSED
                                }
                                block.isDoor() -> {
                                    if (block.isOpened()) BlockPathTypes.DOOR_OPEN else BlockPathTypes.DOOR_WOOD_CLOSED
                                }
                                material.endsWith("LEAVES") || material.endsWith("LEAVES_2") -> {
                                    BlockPathTypes.LEAVES
                                }
                                material.endsWith("FENCE") || material.endsWith("WALL") || (material.endsWith("FENCE_GATE") && !block.isOpened()) -> {
                                    BlockPathTypes.FENCE
                                }
                                block.type.isSolid -> {
                                    BlockPathTypes.BLOCKED
                                }
                                else -> {
                                    BlockPathTypes.OPEN
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // recode: evaluateType
    fun evaluateBlockPathType(world: World, canOpenDoors: Boolean, canPassDoors: Boolean, position: Position, blockPathTypes: BlockPathTypes): BlockPathTypes {
        var pathTypes = blockPathTypes
        if (pathTypes == BlockPathTypes.DOOR_WOOD_CLOSED && canOpenDoors && canPassDoors) {
            pathTypes = BlockPathTypes.WALKABLE_DOOR
        }
        if (pathTypes == BlockPathTypes.DOOR_OPEN && !canPassDoors) {
            pathTypes = BlockPathTypes.BLOCKED
        }
        if (pathTypes == BlockPathTypes.LEAVES) {
            pathTypes = BlockPathTypes.BLOCKED
        }
//        if (pathTypes == BlockPathTypes.RAIL && world.getBlockAt(position) !is BlockMinecartTrackAbstract && world.getType(position.down()).block !is BlockMinecartTrackAbstract) {
//            pathTypes = BlockPathTypes.UNPASSABLE_RAIL
//        }
        return pathTypes
    }

    // recode: getTypeAsNeighbour
    fun checkNeighbourBlocks(world: World, position: Position, blockPathTypes: BlockPathTypes): BlockPathTypes {
        var blockPathTypes1 = blockPathTypes
        val x = position.x
        val y = position.y
        val z = position.z
        for (l in -1..1) {
            for (i1 in -1..1) {
                for (j1 in -1..1) {
                    if (l != 0 || j1 != 0) {
                        val block = world.getBlockAtIfLoaded(position.set(x + l, y + i1, z + j1))
                        if (block == null) {
                            blockPathTypes1 = BlockPathTypes.BLOCKED
                        } else {
                            Material.POTTED_CACTUS
                            if (block.type.name == "CACTUS") {
                                return BlockPathTypes.DANGER_CACTUS
                            }
                            if (block.type.name == "SWEET_BERRY_BUSH") {
                                return BlockPathTypes.DANGER_OTHER
                            }
                            if (isBurningBlock(block)) {
                                return BlockPathTypes.DANGER_FIRE
                            }
                            if (block.getFluid().isWater()) {
                                return BlockPathTypes.WATER_BORDER
                            }
                        }
                    }
                }
            }
        }
        return blockPathTypes1
    }

    // a
    fun getFloorLevel(world: World, position: Position): Double {
        val block = position.down().toBlock(world)
        val blockHeight = NMS.INSTANCE.getBlockHeight(block)
        return if (blockHeight == 0.0) 0.0 else blockHeight + block.y
    }

    // a
    fun isNeighborValid(node: Node?, node1: Node): Boolean {
        return node != null && !node.closed && (node.costMalus >= 0.0f || node1.costMalus < 0.0f)
    }

    // a
    fun isDiagonalValid(node: Node, node1: Node?, node2: Node?, node3: Node?): Boolean {
        return if (node3 != null && node2 != null && node1 != null) {
            if (node3.closed) {
                false
            } else if (node2.y <= node.y && node1.y <= node.y) {
                if (node1.type != BlockPathTypes.WALKABLE_DOOR && node2.type != BlockPathTypes.WALKABLE_DOOR && node3.type != BlockPathTypes.WALKABLE_DOOR) {
                    val flag = node2.type == BlockPathTypes.FENCE && node1.type == BlockPathTypes.FENCE && nodeEntity!!.width < 0.5
                    node3.costMalus >= 0.0f
                            && (node2.y < node.y || node2.costMalus >= 0.0f || flag)
                            && (node1.y < node.y || node1.costMalus >= 0.0f || flag)
                } else {
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    }

    // a
    fun canReachWithoutCollision(node: Node): Boolean {
        val vector = Vector(node.x - nodeEntity!!.location.x, node.y - nodeEntity!!.location.y, node.z - nodeEntity!!.location.z)
        var boundingBox = nodeEntity!!.boundingBox
        val i = f(vector.lengthSqr() / boundingBox.getSize())
        vector.multiply((1.0f / i.toFloat()).toDouble())
        for (j in 1..i) {
            boundingBox = boundingBox.move(vector)
            if (hasCollisions(boundingBox)) {
                return false
            }
        }
        return true
    }

    // a
    fun hasCollisions(boundingBox: BoundingBox): Boolean {
        println("hasCollisions ${boundingBox}")
//        return collisionCache.computeIfAbsent(boundingBox) {
//            !(this.world as CraftWorld).handle.chunkProvider.getCubes(
//                this.b,
//                boundingBox
//            )
//        }
        return false
    }

    // b
    fun hasPositiveMalus(position: Position): Boolean {
        return nodeEntity!!.getPathfindingMalus(getCachedBlockType(nodeEntity!!, position)) >= 0.0f
    }

    // a
    fun isBurningBlock(block: Block): Boolean {
        return block.type.name in listOf("FIRE", "LAVA", "STATIONARY_LAVA", "MAGMA_BLOCK", "CAMPFIRE", "SOUL_CAMPFIRE")
    }

    // a
    fun getLandNode(x: Int, y: Int, z: Int, l: Int, floor: Double, direction: Direction, blockPathType: BlockPathTypes): Node? {
        var y1 = y
        var node: Node? = null
        val position = Position(0, 0, 0)
        val floorLevel = getFloorLevel(world!!, position.set(x, y1, z))
        debug("    getLandNode floorLevel ($x, $y1, $z) -> $floorLevel blockPathType $blockPathType")
        return if (floorLevel - floor > 1.125) {
            null
        } else {
            var pathType1 = getCachedBlockType(nodeEntity!!, x, y1, z)
            if (pathType1 == BlockPathTypes.BLOCKED) {
                pathType1 = getCachedBlockType(nodeEntity!!, x, ++y1, z)
            }
            var f = nodeEntity!!.getPathfindingMalus(pathType1)
            val d2 = nodeEntity!!.width / 2.0
            debug("    getLandNode pathType1 $pathType1 f $f d2 $d2")
            if (f >= 0.0f) {
                node = getNode(x, y1, z)
                node.type = pathType1
                node.costMalus = node.costMalus.coerceAtLeast(f)
            }
            if (blockPathType == BlockPathTypes.FENCE && node != null && node.cost >= 0.0f && !canReachWithoutCollision(node)) {
                node = null
            }
            if (pathType1 == BlockPathTypes.WALKABLE) {
                node
            } else {
                if ((node == null || node.costMalus < 0.0f) && l > 0 && pathType1 != BlockPathTypes.FENCE && pathType1 != BlockPathTypes.UNPASSABLE_RAIL && pathType1 != BlockPathTypes.TRAPDOOR) {
                    node = getLandNode(x, y1 + 1, z, l - 1, floor, direction, blockPathType)
                    if (node != null && (node.type == BlockPathTypes.OPEN || node.type == BlockPathTypes.WALKABLE) && nodeEntity!!.width < 1.0f) {
                        val d3 = (x - direction.getAdjacentX()).toDouble() + 0.5
                        val d4 = (z - direction.getAdjacentZ()).toDouble() + 0.5
                        val boundingBox = BoundingBox(
                            d3 - d2,
                            getFloorLevel(world!!, position.set(d3, (y1 + 1).toDouble(), d4)) + 0.001,
                            d4 - d2,
                            d3 + d2,
                            nodeEntity!!.height + getFloorLevel(world!!, position.set(node.x.toDouble(), node.y.toDouble(), node.z.toDouble())) - 0.002,
                            d4 + d2
                        )
                        if (hasCollisions(boundingBox)) {
                            node = null
                        }
                    }
                }
                if (pathType1 == BlockPathTypes.WATER && !canFloat) {
                    if (getCachedBlockType(nodeEntity!!, x, y1 - 1, z) != BlockPathTypes.WATER) {
                        return node
                    }
                    while (y1 > 0) {
                        --y1
                        pathType1 = getCachedBlockType(nodeEntity!!, x, y1, z)
                        if (pathType1 != BlockPathTypes.WATER) {
                            return node
                        }
                        node = getNode(x, y1, z)
                        node.type = pathType1
                        node.costMalus = node.costMalus.coerceAtLeast(nodeEntity!!.getPathfindingMalus(pathType1))
                    }
                }
                if (pathType1 == BlockPathTypes.OPEN) {
                    var i1 = 0
                    var j1 = y1
                    while (pathType1 == BlockPathTypes.OPEN) {
                        --j1
                        if (j1 < 0) {
                            val node1 = getNode(x, j1, z)
                            node1.type = BlockPathTypes.BLOCKED
                            node1.costMalus = -1.0f
                            return node1
                        }
                        if (i1++ >= nodeEntity!!.getAirSupply()) {
                            debug("    getLandNode outOfAirSupply $i1")
                            val node1 = getNode(x, j1, z)
                            node1.type = BlockPathTypes.BLOCKED
                            node1.costMalus = -1.0f
                            return node1
                        }
                        pathType1 = getCachedBlockType(nodeEntity!!, x, j1, z)
                        f = nodeEntity!!.getPathfindingMalus(pathType1)
                        debug("    getLandNode pathType1 $pathType1 f $f j1 $j1 block ${Position(x, j1, z).toBlock(world!!).type}")
                        if (pathType1 != BlockPathTypes.OPEN && f >= 0.0f) {
                            node = getNode(x, j1, z)
                            node.type = pathType1
                            node.costMalus = node.costMalus.coerceAtLeast(f)
                            break
                        }
                        if (f < 0.0f) {
                            val node1 = getNode(x, j1, z)
                            node1.type = BlockPathTypes.BLOCKED
                            node1.costMalus = -1.0f
                            return node1
                        }
                    }
                }
                if (pathType1 == BlockPathTypes.FENCE) {
                    node = getNode(x, y1, z)
                    node.closed = true
                    node.type = pathType1
                    node.costMalus = pathType1.malus
                }
                node
            }
        }
    }
}