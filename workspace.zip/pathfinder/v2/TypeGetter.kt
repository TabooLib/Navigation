package ink.ptms.navigation.pathfinder.v2

import ink.ptms.navigation.pathfinder.BlockPathTypes
import ink.ptms.navigation.pathfinder.Fluid.Companion.getFluid
import ink.ptms.navigation.pathfinder.NodeEntity
import ink.ptms.navigation.util.*
import io.izzel.taboolib.module.nms.impl.Position
import org.bukkit.World
import java.util.*
import kotlin.math.ceil

@Suppress("LiftReturnOrAssignment")
class TypeGetter(val entity: NodeEntity) {

    val world = entity.location.world!!

    /**
     * 评估类型
     * 根据实体自身条件判断是否可以穿过该方块
     */
    fun evaluateType(blockPathTypes: BlockPathTypes): BlockPathTypes {
        return when {
            blockPathTypes == BlockPathTypes.DOOR_WOOD_CLOSED && entity.canOpenDoors && entity.canPassDoors -> {
                BlockPathTypes.WALKABLE_DOOR
            }
            blockPathTypes == BlockPathTypes.DOOR_OPEN && !entity.canPassDoors -> {
                BlockPathTypes.BLOCKED
            }
            blockPathTypes == BlockPathTypes.LEAVES -> {
                BlockPathTypes.BLOCKED
            }
            else -> blockPathTypes
        }
    }

    /**
     * 获取方块类型
     * 主要目的是判断实体的碰撞箱是否允许通过该空间
     */
    fun getTypeAsBoundingBox(x: Int, y: Int, z: Int): BlockPathTypes {
        val cover = EnumSet.noneOf(BlockPathTypes::class.java)
        val coverType = getTypeAsBoundingBox(x, y, z, cover)
        if (cover.contains(BlockPathTypes.FENCE)) {
            return BlockPathTypes.FENCE
        }
        var passable = BlockPathTypes.BLOCKED
        cover.forEach {
            // 假设实体无法通过该方块
            // 则返回该方块类型
            if (entity.getPathfindingMalus(it) < 0.0f) {
                return it
            }
            // 当实体能够通过该方块
            // 则记录该方块
            if (entity.getPathfindingMalus(it) >= 0) {
                passable = it
            }
        }
        // 假设中心方块可通过，且附近无危险方块，怪物宽度小于等于 1 格
        // 则允许通过
        if (coverType === BlockPathTypes.OPEN && entity.getPathfindingMalus(passable) == 0.0f && entity.width <= 1) {
            return BlockPathTypes.OPEN
        } else {
            // 否则返回危险方块
            return passable
        }
    }

    /**
     * 获取方块类型
     * 主要目的是判断实体的碰撞箱是否允许通过该空间
     *
     * @param x x
     * @param y y
     * @param z z
     * @param cover 实体自身碰撞箱覆盖的所有方块类型
     */
    fun getTypeAsBoundingBox(x: Int, y: Int, z: Int, cover: EnumSet<BlockPathTypes>): BlockPathTypes {
        var pathTypes: BlockPathTypes? = null
        (0 until ceil(entity.width).toInt()).forEach { ox ->
            (0 until ceil(entity.height).toInt()).forEach { oy ->
                (0 until ceil(entity.depth).toInt()).forEach { oz ->
                    // 获取方块类型并评估
                    val type = evaluateType(getTypeAsWalkable(world, Position(ox + x, oy + y, oz + z))).also {
                        cover.add(it)
                    }
                    // 如果是原点则作为方法的返回值
                    if (ox == 0 && oy == 0 && oz == 0) {
                        pathTypes = type
                    }
                }
            }
        }
        return pathTypes!!
    }

    /**
     * 获取方块类型
     * 主要目的为判断方块是否可行走及其行走代价
     *
     * 假设该方块的临近方块存在危险类型
     * 那么该方块也会被视为危险类型
     */
    fun getTypeAsWalkable(world: World, position: Position): BlockPathTypes {
        // 获取原始类型
        var rawType = getRawType(world, position)
        // 当方块可以通过且高度 > 1
        if (rawType == BlockPathTypes.OPEN && position.y >= 1) {
            // 获取下方方块
            val down = getRawType(world, position.down())
            // 对下方方块进行一个初步的判断
            if (down != BlockPathTypes.WALKABLE && down != BlockPathTypes.OPEN && down != BlockPathTypes.WATER && down != BlockPathTypes.LAVA) {
                // WALKABLE 类型的唯一来源，代表方块绝对可站立，但危险等级不知。
                rawType = BlockPathTypes.WALKABLE
            } else {
                rawType = BlockPathTypes.OPEN
            }
            rawType = when (down) {
                BlockPathTypes.DAMAGE_FIRE -> BlockPathTypes.DAMAGE_FIRE
                BlockPathTypes.DAMAGE_CACTUS -> BlockPathTypes.DAMAGE_CACTUS
                BlockPathTypes.DAMAGE_OTHER -> BlockPathTypes.DAMAGE_OTHER
                BlockPathTypes.STICKY_HONEY -> BlockPathTypes.STICKY_HONEY
                else -> rawType
            }
        }
        if (rawType == BlockPathTypes.WALKABLE) {
            // 临近的危险方块将会代替自身返回
            rawType = getTypeAsNeighbour(world, position, rawType)
        }
        return rawType
    }

    /**
     * 获取方块类型
     * 主要目的是获取其临近的危险方块
     */
    fun getTypeAsNeighbour(world: World, position: Position, blockPathTypes: BlockPathTypes): BlockPathTypes {
        (-1..1).forEach { ox ->
            (-1..1).forEach { oy ->
                (-1..1).forEach { oz ->
                    if (ox != 0 || oz != 0) {
                        val block = world.getBlockAtIfLoaded(Position(position.x + ox, position.y + oy, position.z + oz))
                        if (block != null) {
                            val name = block.type.name
                            when {
                                name == "CACTUS" -> {
                                    return BlockPathTypes.DANGER_CACTUS
                                }
                                name == "SWEET_BERRY_BUSH" -> {
                                    return BlockPathTypes.DANGER_OTHER
                                }
                                name.getFluid().isLava() || name in arrayOf("FIRE", "MAGMA_BLOCK", "CAMPFIRE", "SOUL_CAMPFIRE") -> {
                                    return BlockPathTypes.DANGER_FIRE
                                }
                                name.getFluid().isWater() -> {
                                    return BlockPathTypes.WATER_BORDER
                                }
                            }
                        }
                    }
                }
            }
        }
        return blockPathTypes
    }

    /**
     * 获取单个方块当原始类型
     * 不对其临近方块进行判断
     */
    fun getRawType(world: World, position: Position): BlockPathTypes {
        val block = world.getBlockAtIfLoaded(position) ?: return BlockPathTypes.BLOCKED
        val blockType = block.type
        val blockTypeName = blockType.name
        return when {
            // 空气
            blockType.isAir -> {
                BlockPathTypes.OPEN
            }
            // 活板门、睡莲、地毯
            blockTypeName.endsWith("TRAPDOOR") || blockTypeName.endsWith("TRAP_DOOR") || blockTypeName == "LILY_PAD" || blockTypeName == "CARPET" -> {
                // 能够行走，能够穿过。
                BlockPathTypes.TRAPDOOR
            }
            // 栅栏，石墙，关闭的栅栏门
            blockTypeName.endsWith("FENCE") || blockTypeName.endsWith("WALL") || (blockTypeName.endsWith("FENCE_GATE") && !block.isOpened()) -> {
                // 与 Blocked 不同，Fence 拥有 1.5 格高度无法越过。
                BlockPathTypes.FENCE
            }
            // 树叶
            blockTypeName.endsWith("LEAVES") || blockTypeName.endsWith("LEAVES_2") -> {
                // 与 Blocked 相同，保留类型
                BlockPathTypes.LEAVES
            }
            // 仙人掌
            blockTypeName.endsWith("CACTUS") -> {
                BlockPathTypes.DAMAGE_CACTUS
            }
            // 浆果从
            blockTypeName == "SWEET_BERRY_BUSH" -> {
                BlockPathTypes.DAMAGE_OTHER
            }
            // 蜂蜜块
            blockTypeName == "HONEY_BLOCK" -> {
                BlockPathTypes.STICKY_HONEY
            }
            // 可可豆
            blockTypeName.endsWith("COCOA") -> {
                BlockPathTypes.COCOA
            }
            // 燃烧物
            blockTypeName in arrayOf("FIRE", "MAGMA_BLOCK", "CAMPFIRE", "SOUL_CAMPFIRE") -> {
                // 可以穿过，但会受伤
                BlockPathTypes.DAMAGE_FIRE
            }
            // 铁门
            block.isIronDoor() -> {
                if (block.isOpened()) BlockPathTypes.DOOR_OPEN else BlockPathTypes.DOOR_IRON_CLOSED
            }
            // 木门
            block.isDoor() -> {
                if (block.isOpened()) BlockPathTypes.DOOR_OPEN else BlockPathTypes.DOOR_WOOD_CLOSED
            }
            // 水
            blockTypeName.getFluid().isWater() -> {
                // 可以越过，但会判断条件
                BlockPathTypes.WATER
            }
            // 岩浆
            blockTypeName.getFluid().isLava() -> {
                // 不可越过，但会判断条件
                BlockPathTypes.LAVA
            }
            // 其他实体方块
            block.type.isSolid -> {
                // 不可通过，允许越过
                BlockPathTypes.BLOCKED
            }
            else -> {
                BlockPathTypes.OPEN
            }
        }
    }
}