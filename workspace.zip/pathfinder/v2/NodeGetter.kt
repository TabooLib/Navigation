package ink.ptms.navigation.pathfinder.v2

import ink.ptms.navigation.pathfinder.BlockPathTypes
import ink.ptms.navigation.pathfinder.Direction
import ink.ptms.navigation.pathfinder.Node
import ink.ptms.navigation.pathfinder.NodeEntity
import ink.ptms.navigation.pathfinder.bukkit.NMS
import ink.ptms.navigation.util.debug
import ink.ptms.navigation.util.hash
import ink.ptms.navigation.util.toBlock
import io.izzel.taboolib.module.nms.impl.Position
import it.unimi.dsi.fastutil.ints.Int2ObjectMap
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap
import it.unimi.dsi.fastutil.longs.Long2ObjectMap
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap

class NodeGetter(val entity: NodeEntity) {

    val nodes: Int2ObjectMap<Node> = Int2ObjectOpenHashMap()
    val types: Long2ObjectMap<BlockPathTypes> = Long2ObjectOpenHashMap()
    val typeGetter = TypeGetter(entity)
    val world = entity.location.world!!

    fun getNode(position: Position): Node {
        return getNode(position.x, position.y, position.z)
    }

    fun getNode(x: Int, y: Int, z: Int): Node {
        return nodes.computeIfAbsent(Node.createHash(x, y, z)) { Node(x, y, z) }
    }

    fun getCachedBlockType(x: Int, y: Int, z: Int): BlockPathTypes {
        return getCachedBlockType(Position(x, y, z))
    }

    fun getCachedBlockType(position: Position): BlockPathTypes {
        return types.computeIfAbsent(position.hash()) {
            typeGetter.getTypeAsBoundingBox(position.x, position.y, position.z)
        }
    }

    /**
     * 获取当前坐标下的陆地高度
     * 指最顶层碰撞箱 maxY > 0 的方块
     */
    fun getLandHeight(position: Position): Double {
        val block = position.toBlock(world)
        val blockHeight = NMS.INSTANCE.getBlockHeight(block)
        return if (blockHeight == 0.0) 0.0 else blockHeight + block.y
    }

    /**
     * 获取陆地节点
     *
     * @param x x
     * @param y y
     * @param z z
     * @param l 不知道
     */
    fun getLandNode(x: Int, y: Int, z: Int, l: Int, direction: Direction, blockPathType: BlockPathTypes): Node? {
        var h = y
        var node: Node? = null
        // 获取方块类型
        var pathTypes = getCachedBlockType(x, h, z)
        // 如果被阻挡则尝试越过
        if (pathTypes == BlockPathTypes.BLOCKED) {
            pathTypes = getCachedBlockType(x, ++h, z)
        }
        // 实体是否可以通过该方块
        var malusByEntity = entity.getPathfindingMalus(pathTypes)
        if (malusByEntity >= 0) {
            node = getNode(x, h, z)
            node.type = pathTypes
            node.costMalus = node.costMalus.coerceAtLeast(malusByEntity)
        }
        // todo 此处省略对栏杆的碰撞箱判断
//        if (blockPathType == BlockPathTypes.FENCE && node != null && node.cost >= 0.0f && !canReachWithoutCollision(node)) {
//            node = null
//        }
        if (pathTypes == BlockPathTypes.WALKABLE) {
            return node
        } else {
            // todo 此处省略对栏杆的碰撞箱判断
//            val width = entity.width / 2
//            if ((node == null || node.costMalus < 0.0f) && l > 0 && pathTypes != BlockPathTypes.FENCE && pathTypes != BlockPathTypes.UNPASSABLE_RAIL && pathTypes != BlockPathTypes.TRAPDOOR) {
//                node = getLand(x, h + 1, z, l - 1, fromLandHeight, direction, blockPathType)
//                if (node != null && (node.type == BlockPathTypes.OPEN || node.type == BlockPathTypes.WALKABLE) && nodeEntity!!.width < 1.0f) {
//                    val d3 = (x - direction.getAdjacentX()).toDouble() + 0.5
//                    val d4 = (z - direction.getAdjacentZ()).toDouble() + 0.5
//                    val boundingBox = BoundingBox(
//                        d3 - width,
//                        getLandHeight(world!!, position.set(d3, (h + 1).toDouble(), d4)) + 0.001,
//                        d4 - width,
//                        d3 + width,
//                        nodeEntity!!.height + getLandHeight(world!!, position.set(node.x.toDouble(), node.y.toDouble(), node.z.toDouble())) - 0.002,
//                        d4 + width
//                    )
//                    if (hasCollisions(boundingBox)) {
//                        node = null
//                    }
//                }
//            }

            // 方块类型为水，且实体无法浮在水上
            if (pathTypes == BlockPathTypes.WATER && !entity.canFloat) {
                if (getCachedBlockType(x, h - 1, z) != BlockPathTypes.WATER) {
                    return node
                }
                while (h > 0) {
                    --h
                    pathTypes = getCachedBlockType(x, h, z)
                    if (pathTypes != BlockPathTypes.WATER) {
                        return node
                    }
                    node = getNode(x, h, z)
                    node.type = pathTypes
                    node.costMalus = node.costMalus.coerceAtLeast(entity.getPathfindingMalus(pathTypes))
                }
            }
            // 方块可以通过
            if (pathTypes == BlockPathTypes.OPEN) {
                var airSupply = 0
                var air = h
                while (pathTypes == BlockPathTypes.OPEN) {
                    --air
                    if (air < 0) {
                        val node1 = getNode(x, air, z)
                        node1.type = BlockPathTypes.BLOCKED
                        node1.costMalus = -1.0f
                        return node1
                    }
                    if (airSupply++ >= entity.getAirSupply()) {
                        val node1 = getNode(x, air, z)
                        node1.type = BlockPathTypes.BLOCKED
                        node1.costMalus = -1.0f
                        return node1
                    }
                    pathTypes = getCachedBlockType(x, air, z)
                    malusByEntity = entity.getPathfindingMalus(pathTypes)
                    if (pathTypes != BlockPathTypes.OPEN && malusByEntity >= 0.0f) {
                        node = getNode(x, air, z)
                        node.type = pathTypes
                        node.costMalus = node.costMalus.coerceAtLeast(malusByEntity)
                        break
                    }
                    if (malusByEntity < 0.0f) {
                        node = getNode(x, air, z)
                        node.type = BlockPathTypes.BLOCKED
                        node.costMalus = -1.0f
                        return node
                    }
                }
            }
            if (pathTypes == BlockPathTypes.FENCE) {
                node = getNode(x, h, z)
                node.closed = true
                node.type = pathTypes
                node.costMalus = pathTypes.malus
            }
            return node
        }
    }
}