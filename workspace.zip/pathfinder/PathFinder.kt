package ink.ptms.navigation.pathfinder

import com.google.common.collect.Lists
import ink.ptms.navigation.util.debug
import io.izzel.taboolib.module.nms.impl.Position
import org.bukkit.World
import java.util.*

/**
 * Navigation
 * ink.ptms.navigation.pathfinder.PathFinder
 *
 * @author sky
 * @since 2021/2/21 9:46 下午
 */
class PathFinder(val nodeEvaluator: NodeEvaluator, val maxVisitedNodes: Int) {

    var neighbors = arrayOfNulls<Node>(32)
    val openSet = BinaryHeap()

    fun findPath(world: World, nodeEntity: NodeEntity, position: Set<Position>, followRange: Float, i: Int, f: Float): Path? {
        debug("findPath")
        openSet.clear()
        nodeEvaluator.prepare(world, nodeEntity)
        val start = nodeEvaluator.getStart()
        debug("  getStart(): $start")
        val map = position.map {
            nodeEvaluator.getGoal(it.x.toDouble(), it.y.toDouble(), it.z.toDouble()) to it
        }
        debug("  getGoal(): $map")
        val path = findPath(start, map, followRange, i, f)
        nodeEvaluator.done()
        debug("done")
        return path
    }

    fun findPath(begin: Node, list: List<Pair<Target, Position>>, followRange: Float, i: Int, f: Float): Path? {
        begin.g = 0.0f
        begin.f = getBestHeuristic(begin, list)
        begin.cost = begin.f
        openSet.clear()
        openSet.insert(begin)
        var j = 0
        val set = Lists.newArrayListWithExpectedSize<Pair<Target, Position>>(list.size)
        val k = (maxVisitedNodes * f).toInt()
        while (!openSet.isEmpty()) {
            ++j
            if (j >= k) {
                break
            }
            val pop = openSet.pop()
            pop.closed = true
            var neighbors = 0
            while (neighbors < list.size) {
                val entry = list[neighbors]
                val target = entry.first
                if (pop.distanceManhattan(target) <= i.toFloat()) {
                    target.setReached()
                    set.add(entry)
                }
                ++neighbors
            }
            if (set.isNotEmpty()) {
                break
            }
            if (pop.distanceTo(begin) < followRange) {

                debug("  neighbors 1 ${this.neighbors.filterNotNull()}")
                neighbors = nodeEvaluator.getNeighbors(this.neighbors, pop)
                debug("  neighbors 2 ${this.neighbors.filterNotNull()}")
                debug("  neighbors $neighbors")

                for (index in 0 until neighbors) {
                    val node2 = this.neighbors[index]!!
                    val f2 = pop.distanceTo(node2)
                    node2.walkedDistance = pop.walkedDistance + f2
                    val f3 = pop.cost + f2 + node2.costMalus
                    if (node2.walkedDistance < followRange && (!node2.inOpenSet() || f3 < node2.g)) {
                        node2.cameFrom = pop
                        node2.cost = f3
                        node2.f = getBestHeuristic(node2, list) * 1.5f
                        if (node2.inOpenSet()) {
                            openSet.changeCost(node2, node2.cost + node2.f)
                        } else {
                            node2.g = node2.cost + node2.f
                            openSet.insert(node2)
                        }
                    }
                }
            }
        }
        var best: Path? = null
        val useSet1 = set.isEmpty()
        val comparator = if (useSet1) {
            Comparator.comparingInt { obj: Path -> obj.getNodeCount() }
        } else {
            Comparator.comparingDouble { obj: Path -> obj.distToTarget.toDouble() }.thenComparingInt { obj: Path -> obj.getNodeCount() }
        }
        val iterator = (if (useSet1) list else set).iterator()
        while (true) {
            var path: Path?
            do {
                if (!iterator.hasNext()) {
                    return best
                }
                val entry = iterator.next()
                path = reconstructPath(entry.first.bestNode!!, entry.second, !useSet1)
            } while (best != null && comparator.compare(path, best) >= 0)
            best = path
        }
    }

    fun getBestHeuristic(node: Node, list: List<Pair<Target, Position>>): Float {
        var bestH = 3.4028235E38f
        var i = 0
        val length = list.size
        while (i < length) {
            val target = list[i].first
            val bestHeuristic = node.distanceTo(target)
            target.updateBest(bestHeuristic, node)
            bestH = bestHeuristic.coerceAtMost(bestH)
            ++i
        }
        return bestH
    }

    fun reconstructPath(node: Node, position: Position, flag: Boolean): Path {
        val list = Lists.newArrayList<Node>()
        var node0 = node
        list.add(0, node)
        while (node0.cameFrom != null) {
            node0 = node0.cameFrom!!
            list.add(0, node0)
        }
        return Path(list, position, flag)
    }
}