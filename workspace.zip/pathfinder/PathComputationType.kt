package ink.ptms.navigation.pathfinder

/**
 * Navigation
 * ink.ptms.navigation.pathfinder.PathComputationType
 * net.minecraft.world.level.pathfinder.PathComputationType
 *
 * @author sky
 * @since 2021/2/21 8:19 下午
 */
enum class PathComputationType {

    LAND, WATER, AIR
}