package ink.ptms.navigation.pathfinder

import io.izzel.taboolib.module.nms.impl.Position

/**
 * Navigation
 * ink.ptms.navigation.pathfinder.Direction
 * net.minecraft.world.level.pathfinder.Direction
 *
 * @author sky
 * @since 2021/2/21 6:29 下午
 */
enum class Direction(
    // g
    val data3d: Int,
    // h
    val oppositeIndex: Int,
    // i
    val data2d: Int,
    // j
    val display: String,
    // l
    val axisDirection: AxisDirection,
    // k
    val axis: Axis,
    // m
    val normal: Position
) {

    DOWN(0, 1, -1, "down", AxisDirection.NEGATIVE, Axis.Y, Position(0, -1, 0)),
    UP(1, 0, -1, "up", AxisDirection.POSITIVE, Axis.Y, Position(0, 1, 0)),
    NORTH(2, 3, 2, "north", AxisDirection.NEGATIVE, Axis.Z, Position(0, 0, -1)),
    SOUTH(3, 2, 0, "south", AxisDirection.POSITIVE, Axis.Z, Position(0, 0, 1)),
    WEST(4, 5, 1, "west", AxisDirection.NEGATIVE, Axis.X, Position(-1, 0, 0)),
    EAST(5, 4, 3, "east", AxisDirection.POSITIVE, Axis.X, Position(1, 0, 0));

    fun getAdjacentX(): Int {
        return normal.x
    }

    fun getAdjacentY(): Int {
        return normal.y
    }

    fun getAdjacentZ(): Int {
        return normal.z
    }

    enum class Axis(val id: String) {

        X("x"), Y("y"), Z("z");
    }

    enum class AxisDirection(val id: Int, val display: String) {

        POSITIVE(1, "Towards positive"), NEGATIVE(-1, "Towards negative");

        fun opposite(): AxisDirection {
            return if (this == POSITIVE) NEGATIVE else POSITIVE
        }

        override fun toString(): String {
            return display
        }
    }
}